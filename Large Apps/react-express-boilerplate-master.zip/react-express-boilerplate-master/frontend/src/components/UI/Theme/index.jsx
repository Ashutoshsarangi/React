export default {
  primary_color: '#076090',
  error_color: '#f44335',
  shadow: 'rgba(0,0,0,.2)'
}
