### To run react project use command:
npm start

### Add following files to .gitignore:
.env

### Declare global variables in this file:
config/config.js

### Decare global style in this file:
assets/scss/global.scss

### Declare utilty functions in this file:
utils/index.jsx

### To use private keys use .env file and then decalre it in this file
.env