import React from 'react'

import { Helmet } from "react-helmet";

const Home = () => {
  return (
    <div>
      <Helmet>
        <title>Raj Shah | Home</title>
      </Helmet>
      <h1>Home</h1>
    </div>
  )
}

export default Home;